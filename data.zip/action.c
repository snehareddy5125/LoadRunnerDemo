Action()
{

	web_add_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("ilp-et.s3-website.ap-south-1.amazonaws.com", 
		"URL=http://ilp-et.s3-website.ap-south-1.amazonaws.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/static/js/2.10613d27.chunk.js", ENDITEM, 
		LAST);

	return 0;
}